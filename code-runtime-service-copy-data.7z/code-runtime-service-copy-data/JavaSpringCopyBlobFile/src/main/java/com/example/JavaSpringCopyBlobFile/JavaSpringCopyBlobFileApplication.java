package com.example.JavaSpringCopyBlobFile;

import com.azure.storage.blob.BlobContainerClient;
import com.example.JavaSpringCopyBlobFile.model.Metadata;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.OperationContext;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

import java.io.File;

@SpringBootApplication
@RestController
public class JavaSpringCopyBlobFileApplication {

    // secret => your secret name of key vault
    @Value("${secret}")
    private String connectionString;


    public static void main(String[] args) {
        SpringApplication.run(JavaSpringCopyBlobFileApplication.class, args);
    }

    @GetMapping("get")
    public String get() {
        return connectionString;
    }

    public void run(String... varl) throws Exception {
        System.out.println(String.format("\nConnection String stored in Azure Key Vault:\n%s\n", connectionString));
    }

    @RequestMapping(path = "copy-file", consumes = "application/json", produces = "application/json")
    @ResponseBody
//    public void readFile(@RequestParam String source, @RequestParam String destination) {
    public void readFile(@RequestBody Metadata metadataFile) {
        //example data of metadataFile
        // source : "input/2020/11/04/" => input: container name contain file need copy, /2020/11/04/ : sub folder to blob file
        // destination : "output"       => output container name
        // description : "some description"


        //File sourceFile = null, downloadedFile = null;
        String source = metadataFile.getSource();
        String destination = metadataFile.getDestination();
        
        System.out.println("Azure Blob storage quick start sample");

        CloudStorageAccount storageAccount;
        CloudBlobClient blobClient = null;
        CloudBlobContainer containerInput = null;
//        BlobContainerClient containerInput2 = null;
        CloudBlobContainer containerOutput = null;
        String containerInputname = source.split("/")[0];
        String path = source.substring(source.indexOf("/") + 1);

        try {

            // Parse the connection string and create a blob client to interact with Blob storage
            storageAccount = CloudStorageAccount.parse(connectionString);
            blobClient = storageAccount.createCloudBlobClient();
            containerInput = blobClient.getContainerReference(containerInputname);
            containerOutput = blobClient.getContainerReference(destination);

            Iterable<ListBlobItem> listBlobItems = containerInput.listBlobs(path);

            if (listBlobItems != null) {

                // Create the containerOutput if it does not exist with public access.
                System.out.println("Creating container: " + containerOutput.getName());
                containerOutput.createIfNotExists(BlobContainerPublicAccessType.CONTAINER, new BlobRequestOptions(), new OperationContext());

                for (ListBlobItem blobItem : listBlobItems) {
                    System.out.println("URI of blob is: " + blobItem.getUri());
                    CloudBlockBlob srcblob = new CloudBlockBlob(blobItem.getUri());
                    CloudBlockBlob destblob = containerOutput.getBlockBlobReference(srcblob.getName());
                    // Conpy file to destination container
                    destblob.startCopy(srcblob);

                }
            }


            //Creating a sample file
//			sourceFile = File.createTempFile("sampleFile", ".txt");
//			System.out.println("Creating a sample file at: " + sourceFile.toString());
//			Writer output = new BufferedWriter(new FileWriter(sourceFile));
//			output.write("Hello Azure!");
//			output.close();
//
//			//Getting a blob reference
//			CloudBlockBlob blob = container.getBlockBlobReference(sourceFile.getName());
//
//			//Creating blob and uploading file to it
//			System.out.println("Uploading the sample file ");
//			blob.uploadFromFile(sourceFile.getAbsolutePath());

            //Listing contents of container
//            for (ListBlobItem blobItem : containerInput.listBlobs()) {
//                System.out.println("URI of blob is: " + blobItem.getUri());
//            }

            // Download blob. In most cases, you would have to retrieve the reference
            // to cloudBlockBlob here. However, we created that reference earlier, and
            // haven't changed the blob we're interested in, so we can reuse it.
            // Here we are creating a new file to download to. Alternatively you can also pass in the path as a string into downloadToFile method: blob.downloadToFile("/path/to/new/file").
//			downloadedFile = new File(sourceFile.getParentFile(), "downloadedFile.txt");
//			blob.downloadToFile(downloadedFile.getAbsolutePath());
        } catch (StorageException ex) {
            System.out.println(String.format("Error returned from the service. Http code: %d and error code: %s", ex.getHttpStatusCode(), ex.getErrorCode()));
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {

        }
    }

}
