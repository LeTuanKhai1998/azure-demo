package com.example.JavaSpringCopyBlobFile.model;

import lombok.Data;

@Data
public class Metadata {

    private String source;
    private String destination;
    private String description;
}
