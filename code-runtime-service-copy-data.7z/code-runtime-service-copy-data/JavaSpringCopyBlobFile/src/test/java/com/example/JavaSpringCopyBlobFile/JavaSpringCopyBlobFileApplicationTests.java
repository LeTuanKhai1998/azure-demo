package com.example.JavaSpringCopyBlobFile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSpringCopyBlobFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
