az login --service-principal --username 280c959e-4a08-44b2-a857-1263ba11eccd --password TghaR2-LU8HbAy~88-0J26TWbOd7Pvs_3t --tenant b1f85ea5-700e-41eb-8bb2-d1c6e728a8f8

az account set --subscription payas

az deployment group create --resource-group rgwebappcopyblobfilekhai --template-file armWebAppCopyBlobFile.json --parameters armWebAppCopyBlobFile.parameters.json
